TESTING_HOST_IP=$1
TESTING_HOST_PORT=$2
CODE_DIR=$3

ssh vagrant@$TESTING_HOST_IP 'tmux new -s pytest_server -d "server15441=\'$TESTING_HOST\' serverport15441=\'$TESTING_HOST_PORT\' bash -c $CODE_DIR/server"'

