#!/usr/bin/env python
import datetime
import requests
import os
import time
from grader import grader, tester
import hashlib
import random
import lowlevelhttptests
from subprocess import Popen, PIPE, STDOUT
import os.path
import socket

#RequestException


BIN = "./lisod"

MIME = {
    '.html' : 'text/html',
    '.css'  : 'text/css',
    '.png'  : 'image/png',
    '.jpg'  : 'image/jpeg',
    '.gif'  : 'image/gif',
    ''      : 'application/octet-stream'
}


class project1cp2tester(tester):

    def __init__(self, test_name, testsuit):
        super(project1cp2tester, self).__init__(test_name, testsuit)

    def test_kill(self):
        if self.testsuite.process is None:
            self.skipTest("server failed to start. skip this test")
        print "kill it"
        self.testsuite.process.terminate()
        return

    def start_server(self):
        if not os.path.isfile("lisod"):
            if os.path.isfile("echo_server"):
                print "Your makefile should make a binary called lisod, \
                        not echo_server!"
            self.skipTest("lisod not found. Skip this test")

        print "Try to start server!"
        self.testsuite.port = random.randint(1025, 9999)
        self.testsuite.tls_port = random.randint(1025, 9999)
        

        cmd = '%s %d %d ./lisod.log %slisod.lock %s %s %s %s' % \
                (BIN, self.testsuite.port, self.testsuite.tls_port, \
                self.testsuite.tmp_dir, \
                self.testsuite.www[:-1], self.testsuite.cgi, \
                self.testsuite.priv_key, self.testsuite.cert)
        print cmd
        fp = open(os.devnull, 'w')
        p = Popen(cmd.split(' '), stdout=fp, stderr=fp)
        print "Wait 10 seconds."
        time.sleep(10)
        if p.poll() is None:
            print "Server is running"
            self.testsuite.process = p
            self.testsuite.scores['server_start'] = 0.8
        else:
            raise Exception("server dies within 2 seconds!")

    def test_GET(self):
        try:
            print '----- Testing GET -----'
            if self.testsuite.process is None:
                self.skipTest("server failed to start. skip this test")
            time.sleep(1)
            for test in self.testsuite.tests:
                response = requests.get(test % self.testsuite.port, timeout=10.0)
                contenthash = hashlib.sha256(response.content).hexdigest()
                self.pAssertEqual(200, response.status_code)
                self.pAssertEqual(contenthash, self.testsuite.tests[test][0])
            self.testsuite.scores['test_GET'] = 2
            err, res, status = lowlevelhttptests.check_correct_GET('127.0.0.1',\
                            self.testsuite.port)
            if res > 1:
                self.testsuite.scores['test_GET'] -= 1
                print "Received %d responses, should get only 1" % res
                if err:
                    print "And, some of them reported error" % res
        except socket.error:
            print("Socket not responsive")    
        except Exception as e: 
            print(e)



class project1cp2grader(grader):

    def __init__(self, checkpoint):
        super(project1cp2grader, self).__init__()
        self.process = None
        self.checkpoint = checkpoint
       
        
        self.tests = {
            'http://127.0.0.1:%d/index.html' :
            ('f5cacdcb48b7d85ff48da4653f8bf8a7c94fb8fb43407a8e82322302ab13becd', 802),
            'http://127.0.0.1:%d/images/liso_header.png' :
            ('abf1a740b8951ae46212eb0b61a20c403c92b45ed447fe1143264c637c2e0786', 17431),
            'http://127.0.0.1:%d/style.css' :
            ('575150c0258a3016223dd99bd46e203a820eef4f6f5486f7789eb7076e46736a', 301)
        }

    def prepareTestSuite(self):
        super(project1cp2grader, self).prepareTestSuite()
        self.suite.addTest(project1cp2tester('start_server', self))
        self.suite.addTest(project1cp2tester('test_GET', self))
        self.suite.addTest(project1cp2tester('kill_server', self))
        self.scores['start_server'] = 0
        self.scores['test_GET'] = 0
        

    def setUp(self):
        self.tmp_dir = "../tmp/"
        self.priv_key = os.path.join(self.tmp_dir, 'grader.key')
        self.cert = os.path.join(self.tmp_dir, 'grader.crt')
        self.www = os.path.join(self.tmp_dir, 'www/')
        self.cgi = os.path.join(self.tmp_dir, 'cgi/cgi_script.py')


if __name__ == '__main__':
    p1cp2grader = project1cp2grader("checkpoint-2")
    p1cp2grader.prepareTestSuite()
    p1cp2grader.setUp()
    results = p1cp2grader.runTests()
    p1cp2grader.reportScores()
